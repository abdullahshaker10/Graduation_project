#data preprocessing 

#read dataset
dataset = read.csv('Data.csv')

#deal with missing data 

dataset$Age = ifelse(is.na(dataset$Age),
                     ave(dataset$Age, Fun = function(x) mean(x,na.rm = True)),
                     dataset$Age)

