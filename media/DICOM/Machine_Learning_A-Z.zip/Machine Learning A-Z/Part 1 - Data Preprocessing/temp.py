#data preprocicnig

#import libraires
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd 
import os 

#import dataset
data_dir = 'F:/data_set'
patients = os.listdir(data_dir)
